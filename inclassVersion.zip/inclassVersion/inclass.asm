.text
main:
    lui gp, 4                  # gp = 0x4000

loop:
    lw t0, 0(gp)               # case id
    lw x5, 4(gp)               # A
    lw t2, 8(gp)               # B

    add x7, x5, t2

store_result:
    sw x7, 12(gp)
    jal zero, loop